CREATE TABLE `Projects` (id int(11) NOT NULL, `name` varchar(255) DEFAULT NULL, `code` varchar(255) DEFAULT NULL, PRIMARY KEY (id));
insert into `Projects` (`id`, `name`, `code`) values (1,'DevOps','DO180');
