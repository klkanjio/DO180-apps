#!/bin/bash

podman build -t do180-mysql-80-rhel8 .
