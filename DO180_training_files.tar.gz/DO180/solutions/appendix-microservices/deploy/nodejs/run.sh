#!/bin/sh
node app.js

