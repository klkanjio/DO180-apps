<?php
print "Hello, World! php version is " . PHP_VERSION . "\n";
Print "A change is in the air!\n";
?>
